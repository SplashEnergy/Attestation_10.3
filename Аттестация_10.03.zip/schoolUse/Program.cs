﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classSchool;



namespace schoolUse
{
    class Program
    {
        public static SchoolMethods cls = new SchoolMethods();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();

            List<Students> students = new List<Students>
            {
                new Students(2018,818,"Горелов Павел Александрович"),
                new Students(2018,818,"Пименов Ульян Владимировичч"),
                new Students(2019,819,"Бровкин Егор Викторович"),
                new Students(2019,819,"Маркин Илья Алексеевич"),
                new Students(2020,820,"Юнусов Александр Ильдусович"),
                new Students(2020,820,"Печняк Александр Сергеевич"),
                new Students(2021,821,"Жучкин Владимир Павлович"),
                new Students(2021,821,"Герасименко Толик Антонович"),
                new Students(2022,822,"Гжегожевский Эксперт Антошович")
            };

            //Заполнение оценками
            marks.AddRange(cls.GetMarks(DateTime.Parse("06.08.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("04.01.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("23.03.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("12.06.2022"), students));

            //Вывод всех оценок
            Console.WriteLine("Все оценки");
            foreach (Mark m in marks) Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.student.fio}");
            
            Console.WriteLine();

            //Вывод прогулов за месяцы
            Console.WriteLine("Прогулы за месяцы");
            foreach (int i in cls.GetCountTruancy(marks)) Console.WriteLine(i);
            Console.WriteLine();

            //Вывод болезней за месяц
            Console.WriteLine("Болезни за месяцы");
            foreach (int i in cls.GetCountDisease(marks)) Console.WriteLine(i);
            Console.WriteLine();

            //Студенческие билеты студентов
            Console.WriteLine("Номера студенческих билетов");
            foreach (Students std in students) Console.WriteLine(cls.GetStudNumber(std.year, std.group, std.fio));
            Console.WriteLine();

            //Среднее арифметическое оценок в меньшую сторону
            Console.WriteLine("Среднее арифметическое");
            Console.WriteLine(cls.MinAVG(new string[6]{ "4","5","5","б","п"," "}));
            Console.ReadKey();

        }
    }
}
